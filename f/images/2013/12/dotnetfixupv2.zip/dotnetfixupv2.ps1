# determine the framework and ebs guids.  these will be unique for each install

$productskey =  "HKLM:\SOFTWARE\Classes\Installer\Products"
$installedproducts = get-childitem $productskey
$guidstofix = 1..6

foreach ($product in $installedproducts)
{

	$product = $product -replace("HKEY_LOCAL_MACHINE","HKLM:")
	$PackageCode = get-itemproperty -path $product -name "PackageCode"

	if ($PackageCode.PackageCode -match "4C78A69B7517C0446978C7906EBD7950")
		{ $guidstofix[0] = $PackageCode.PackageCode 
		  $guidstofix[1] = $product.Substring($product.LastIndexOf("\")+1)
		}

	elseif ($PackageCode.PackageCode -match "971651411F68D9B4CAF6FCDFB652BB9F")
		{ $guidstofix[2] = $PackageCode.PackageCode
		  # get the guid from the name of the key
		  $guidstofix[3] = $product.Substring($product.LastIndexOf("\")+1)	
		 }

	elseif ($PackageCode.PackageCode -match "89C1D03477CD8054881EFCE6FAAFB588")
		{ $guidstofix[4] = $PackageCode.PackageCode
		  $guidstofix[5] = $product.Substring($product.LastIndexOf("\")+1)
		 }


}

# get a list of the registry keys to parse

$regkeys = reg query HKLM\Software\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-18 /s


# find and replace all instances of D?\ with C?\

for ($i = 0; $i -lt $regkeys.Length; $i++)
{

	if ( ($regkeys[$i] -match "D\?\\") -or ($regkeys[$i] -match "C\\\?\\\\") )
	{

		$badkey = $regkeys[$i-1]
		$badkey = $badkey -replace("HKEY_LOCAL_MACHINE","HKLM:")

		for ($j = 0; $j -lt $guidstofix.count; $j++)

		{

			$badvalue = (get-itemproperty $badkey $guidstofix[$j] -ea silentlycontinue).($guidstofix[$j])


			# filter out null values
 			if ($badvalue -match "^D\?\\") 
			{
				$goodvalue = $badvalue -replace ("D\?\\", "C?\") 
				set-itemproperty -path $badkey -name $guidstofix[$j] -value $goodvalue 
				write-host ":::::replacing $badvalue with $goodvalue"	
			}
 			elseif ( $badvalue -match "^C\\\?\\\\")
			{
				$goodvalue = $badvalue -replace ("^C\\\?\\\\", "C:\") 
				set-itemproperty -path $badkey -name $guidstofix[$j] -value $goodvalue 
				write-host ":::::replacing $badvalue with $goodvalue"	
			}
		}


	}
}


# now replace c\\?\\\\ with c:\\



if(!(test-path "C:\Windows\Microsoft.NET\Framework\v3.5\WFServicesReg.exe"))
{


	write-host -fore 'Red' -back 'Black' "Please copy WFServicesReg.exe from a working installation to C:\Windows\Microsoft.NET\Framework\v3.5

"


}

if(!(test-path "C:\Windows\Microsoft.NET\Framework64\v3.5\WFServicesReg.exe"))
{



write-host -fore 'Red' -back 'Black' "Please copy WFServicesReg.exe from a working installation to C:\Windows\Microsoft.NET\Framework64\v3.5"


}