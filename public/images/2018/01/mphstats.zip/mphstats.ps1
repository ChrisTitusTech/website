﻿$api_key = 'ENTERKEYHERE'
$autoexchangecoin = 'litecoin'

$ScriptDir = Split-Path $MyInvocation.MyCommand.Path -Parent
$ScriptName = $MyInvocation.MyCommand.Name

function call-self 
{
	Start-Process -FilePath "C:\WINDOWS\system32\WindowsPowerShell\v1.0\Powershell.exe" -ArgumentList .\$ScriptName -WorkingDirectory $PSScriptRoot -NoNewWindow
	EXIT
}

Function Get-LtcStats
{
    Clear-Host
    $base_url = 'miningpoolhub.com/index.php?page=api&action=getdashboarddata'
    $URL = "http://$($autoexchangecoin).$($base_url)&api_key=$($api_key)&id="
	$WebRequest = Invoke-WebRequest $URL | ConvertFrom-Json
    $data = $WebRequest.getdashboarddata.data
    $autoexchangesymbol = $($data.pool.info.currency)
	$USDURL = "https://min-api.cryptocompare.com/data/price?fsym=$($autoexchangesymbol)&tsyms=USD"
    $WebRequestUSD = Invoke-WebRequest $USDURL | ConvertFrom-Json
    $usddata = $WebRequestUSD | ForEach-Object {$_ -replace '[\D-[.]]',''}
	$24hourrate = "{0:N5}" -f $data.recent_credits_24hours.amount
	$usddata = [float]$usddata
	$24hourrate = [float]$24hourrate
	$24hourincome = ($usddata*$24hourrate)
    $24hourincome = "{0:N2}" -f $24hourincome
	$lastcredit1 = "{0:N5}" -f $data.recent_credits[0].amount
	$lastcredit2 = "{0:N5}" -f $data.recent_credits[1].amount
	$lastcredit3 = "{0:N5}" -f $data.recent_credits[2].amount
	Write-Host ""
    Write-Host ""
    Write-Host ""
    Write-Host ""
    Write-Host ""
    Write-Host ""
    Write-Host ""
    Write-Host ""
	Write-Host "`r`nStatistics for: $($data.pool.info.name)" -BackgroundColor Black
	Write-Host "Current USD Rate of $($autoexchangecoin) is `$$($usddata)"
    Write-Host "Estimated Balance:`t $($data.balance.confirmed + $data.balance.unconfirmed)"
    Write-Host "24-Hour rate:`t $($24hourrate) $($autoexchangesymbol)"
	Write-Host "24-Hour income:`t `$$($24hourincome)"
    Write-Host "Last Credit 1:`t $($data.recent_credits[0].date)`t $($lastcredit1) $($autoexchangesymbol)"
    Write-Host "Last Credit 2:`t $($data.recent_credits[1].date)`t $($lastcredit2) $($autoexchangesymbol)"
    Write-Host "Last Credit 3:`t $($data.recent_credits[2].date)`t $($lastcredit3) $($autoexchangesymbol)"
}

Function Get-AllStats
{
    $base_url = 'https://miningpoolhub.com/index.php?page=api&action=getuserallbalances'
    $URL = "$($base_url)&api_key=$($api_key)&id="
    $WebRequest = Invoke-WebRequest $URL | ConvertFrom-Json
    $data = $WebRequest.getuserallbalances.data
    $displayarray = @()
    For ($i=1; $i -lt $data.Count; $i++) {
        $assetcoin = $($data[$i].coin)
        $walletbalance = $($data[$i].confirmed + $data[$i].unconfirmed)       
		$walletbalance = [float]$walletbalance
        $exchangebalance = $($data[$i].ae_confirmed + $data[$i].ae_unconfirmed + $data[$i].exchange)     
		$exchangebalance = [float]$exchangebalance
            $base_url2 = 'miningpoolhub.com/index.php?page=api&action=getdashboarddata'
            $URL2 = "http://$($assetcoin).$($base_url2)&api_key=$($api_key)&id="
            $WebRequest2 = Invoke-WebRequest $URL2 | ConvertFrom-Json
            $data2 = $WebRequest2.getdashboarddata.data
            $assethash = $data2.personal.hashrate  
            $assethash = "{0:N3}" -f $assethash  
			$exchangesymbol = $($data2.pool.info.currency)
			$USDURL = "https://min-api.cryptocompare.com/data/price?fsym=$($exchangesymbol)&tsyms=USD"
			$WebRequestUSD = Invoke-WebRequest $USDURL | ConvertFrom-Json
			$usddata = $WebRequestUSD | ForEach-Object {$_ -replace '[\D-[.]]',''}
			$usddata = [float]$usddata
			$poolamount = $usddata*($walletbalance+$exchangebalance)
			$totalpoolamount = $poolamount+$totalpoolamount
		#Formatting Table
		$poolamount = "{0:N2}" -f $poolamount
		$poolamount = [string]$poolamount
		$poolamount = '$'+$poolamount
		$usddata = "{0:N2}" -f $usddata
		$usddata = [string]$usddata
		$usddata = '$'+$usddata
		$exchangebalance = "{0:N5}" -f $exchangebalance
		$walletbalance = "{0:N5}" -f $walletbalance
		#Setup Array for Table
        $objoutput = new-object psobject -Property @{
            Coin = $assetcoin
            Wallet = $walletbalance
            Exchange = $exchangebalance
            HashRate = $assethash
			MarketRate = $usddata
			PoolAmount = $poolamount
            }
            $displayarray += $objoutput

    }
	$totalpoolamount = "{0:N2}" -f $totalpoolamount
    $displayarray | Format-Table Coin, Wallet, Exchange, HashRate, MarketRate, PoolAmount -auto
	Write-Host "Total Amount on Pool: `$$($totalpoolamount)"
}

function Start-Sleep($seconds) {
    $doneDT = (Get-Date).AddSeconds($seconds)
    while($doneDT -gt (Get-Date)) {
        $secondsLeft = $doneDT.Subtract((Get-Date)).TotalSeconds
        $percent = ($seconds - $secondsLeft) / $seconds * 100
        Write-Progress -Activity "Sleeping" -Status "Refresh in..." -SecondsRemaining $secondsLeft -PercentComplete $percent
        [System.Threading.Thread]::Sleep(500)
    }
    Write-Progress -Activity "Sleeping" -Status "..." -SecondsRemaining 0 -Completed
}

Get-LtcStats
Get-AllStats
Start-Sleep(300)
call-Self # Restart the script
##### The End of the World as we know it #####
EXIT